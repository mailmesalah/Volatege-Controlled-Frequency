/************************************************************************/
/*																		*/
/*	DACSPI2.h	--	Declaration for DACSPI2 library 	    			*/
/*																		*/
/************************************************************************/
/*	Author:		Cristian Fatu											*/
/*	Copyright 2012, Digilent Inc.										*/
/************************************************************************/
/*  File Description:													*/
/*	This file declares the DACSPI2 library functions and the constants	*/
/*	involved.															*/
/*																		*/
/************************************************************************/
/*  Revision History:													*/
/*																		*/
/*	01/12/2012(CristianF): created										*/
/*																		*/
/************************************************************************/
#if !defined(DACSPI2_H)
#define DACSPI2_H

/* ------------------------------------------------------------ */
/*				Include File Definitions						*/
/* ------------------------------------------------------------ */
#include <inttypes.h>
#include <DSPI.h>

/* ------------------------------------------------------------ */
/*					Definitions									*/
/* ------------------------------------------------------------ */
#define DACSPI2_NO_BITS		12

#define DACSPI2_SPI_FREQ	1000000 // 1 MHz - default spi freq
#define	PAR_ACCESS_SPI0			0
#define	PAR_ACCESS_SPI1			1
#define	PAR_ACCESS_I2C			2	

/* ------------------------------------------------------------ */
/*					Errors Definitions							*/
/* ------------------------------------------------------------ */

#define DACSPI2_ERR_SUCCESS				0	// The action completed successfully
#define DACSPI2_ERR_VAL_OUT_OF_RANGE	1	// The value is out of range

/* ------------------------------------------------------------ */
/*					Procedure Declarations						*/
/* ------------------------------------------------------------ */


class DACSPI2 {
private: 
	DSPI *pdspi;
	uint8_t m_SSPin;

public:
	uint8_t WriteIntegerValue(uint16_t wIntegerValue);
	uint8_t WritePhysicalValue(float dPhysicalValue, float dReference = 3.3);

	DACSPI2();
	void begin(uint8_t bAccessType);
};



#endif