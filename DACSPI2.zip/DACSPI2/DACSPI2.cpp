/************************************************************************/
/*																		*/
/*	DACSPI2.cpp		--		Definition for DACSPI2 library 	    		*/
/*																		*/
/************************************************************************/
/*	Author:		Cristian Fatu											*/
/*	Copyright 2012, Digilent Inc.										*/
/************************************************************************/
/*  File Description:													*/
/*		This file defines functions for DACSPI2							*/
/*																		*/
/************************************************************************/
/*  Revision History:													*/
/*																		*/
/*	01/12/2012(CristianF): created										*/
/*																		*/
/************************************************************************/


/* ------------------------------------------------------------ */
/*				Include File Definitions						*/
/* ------------------------------------------------------------ */
#include "DACSPI2.h"
#include <Dspi.h>


/* ------------------------------------------------------------ */
/*				Procedure Definitions							*/
/* ------------------------------------------------------------ */


/* ------------------------------------------------------------ */
/*        DACSPI2::DACSPI2
**
**        Synopsis:
**				
**        Parameters:
**
**
**
**        Return Values:
**                void 
**
**        Errors:
**
**
**        Description:
**			Class constructor. Performs variables initialization tasks
**
**
*/
DACSPI2::DACSPI2()
{
	pdspi = NULL;
}

/* ------------------------------------------------------------ */
/*        DACSPI2::WriteIntegerValue
**
**        Synopsis:
**				WriteIntegerValue(wIntegerValue);
**        Parameters:
**				- uint16_t wIntegerValue - the 12 bits value to be written to DA converter 
**
**        Return Value:
**                uint8_t 
**					- DACSPI2_ERR_SUCCESS (0) 				- The action completed successfully 
**					- DACSPI2_ERR_VAL_OUT_OF_RANGE	(1) 	- The value is not within the 0 - 0xFFF range
**
**        Errors:
**			If module is not initialized (using begin), the function does nothing. Also, see return value.
**
**        Description:
**			If the value is within the allowed range (0 - 0xFFF), this function writes the 12 bits value to the DA converter, and returns the DACSPI2_ERR_SUCCESS status message.
**			If the value is outside the allowed range, the function does nothing and returns the DACSPI2_ERR_VAL_OUT_OF_RANGE message.
**
**
*/
uint8_t DACSPI2::WriteIntegerValue(uint16_t wIntegerValue)
{
	uint8_t bResult = 0;
	uint8_t *pbValue = (uint8_t *)&wIntegerValue;
	if(wIntegerValue < 0 || wIntegerValue >= (1 << DACSPI2_NO_BITS))
	{
		bResult = DACSPI2_ERR_VAL_OUT_OF_RANGE;
	}
	else
	{
		bResult = DACSPI2_ERR_SUCCESS;
		if(pdspi != NULL)
		{
			// make SS active
			digitalWrite(m_SSPin, LOW);		
			
			// write to SPI, two separate 8 bits values
			pdspi->transfer(*(pbValue + 1)); // high byte
			pdspi->transfer(*pbValue);	// low byte

			// make SS inactive
			digitalWrite(m_SSPin, HIGH);
		}
	}
	return bResult;
}

/* ------------------------------------------------------------ */
/*        DACSPI2::WritePhysicalValue
**
**        Synopsis:
**				 myDACSPI2.WritePhysicalValue(dValue);
**        Parameters:
**				- float dPhysicalValue - the physical value that must be reconstructed at the output of the DA converter
**				- float dReference - the value corresponding to the maximum converted value (reference voltage). If this parameter is not provided, it has a default value of 3.3.
**									
**
**        Return Values:
**                uint8_t 
**					- DACSPI2_ERR_SUCCESS (0) 				- The action completed successfully 
**					- DACSPI2_ERR_VAL_OUT_OF_RANGE	(1) 	- The physical value is not inside accepted range
**
**        Errors:
**			If module is not initialized (using begin), the function does nothing. Also, see return value.
**
**        Description:
**			The function computes the integer value corresponding to the physical value by considering the reference value as the one corresponding to the maximum integer value (0xFFF).
**			If the integer value is within the accepted range (0 - 0xFF), this function writes the 8-bit value to the DA converter and returns the DACSPI1_ERR_SUCCESS message.
**			If the integer value is outside the allowed range, the function does nothing and returns the DACSPI1_ERR_VAL_OUT_OF_RANGE message.
**			If the dReference function argument is missing, 3.3 value is used as reference value.
**
*/
uint8_t DACSPI2::WritePhysicalValue(float dPhysicalValue, float dReference)
{
	uint16_t wIntegerValue = dPhysicalValue * (float)((1<<DACSPI2_NO_BITS) - 1) / dReference;
	return WriteIntegerValue(wIntegerValue);
}

/* ------------------------------------------------------------ */
/*        DACSPI2::begin
**
**        Synopsis:
**				myDACSPI2.begin(PAR_ACCESS_SPI0);
**        Parameters:
**				uint8_t bAccessType	- the SPI interface where the Pmod is connected. It can be one of:
**					0	PAR_ACCESS_SPI0	- indicates SPI port 2, connetor JB
**					1	PAR_ACCESS_SPI1	- indicates SPI port 1, connector J1
**
**
**        Return Values:
**                void 
**
**        Errors:
**
**
**        Description:
**				This function initializes the specific SPI interface used, setting the SPI frequency to a default value of 1 MHz.
**
**
*/
void DACSPI2::begin(uint8_t bAccessType)
{
	if(bAccessType == PAR_ACCESS_SPI0)
	{
		pdspi = new DSPI0();
		m_SSPin = PIN_DSPI0_SS;	// default SS pin for SPI0
	}
	if(bAccessType == PAR_ACCESS_SPI1)
	{
		pdspi = new DSPI1();
		m_SSPin = PIN_DSPI1_SS;	// default SS pin for SPI1
	}
	if(pdspi != NULL)
	{
		pdspi->begin(m_SSPin);	// this defines SS pin as output, sets SS high
		pdspi->setMode(DSPI_MODE3);
		pdspi->setSpeed(DACSPI2_SPI_FREQ);
	}
}





